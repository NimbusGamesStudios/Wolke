/* ============================================================
   launcher.js  -  Der Wolken Launcher
   ------------------------------------------------------------
   Der Launcher kann in ZWEI Umgebungen laufen:

     PROGRAMM-MODUS   (wolken.py / Wolken.exe)
       Ein eigenes Programm hat den Server gestartet. Es kann
       richtige Dateien auf die Festplatte schreiben. Spiele
       landen in einem Ordner, den man im Explorer oeffnen kann.

     BROWSER-MODUS    (nur eine Webseite)
       Kein Programm dahinter. Dann bleibt nur der Speicher, den
       der Browser selbst anbietet: die Cache Storage API.

   Damit der Rest des Codes davon nichts wissen muss, gibt es
   fuer beide Faelle ein Objekt mit denselben vier Funktionen:

        status()        Was ist installiert?
        katalog()       Welche Spiele gibt es?
        installieren()  Spiel holen
        entfernen()     Spiel loeschen

   Beim Start wird geprueft, welche Umgebung vorliegt, und das
   passende Objekt eingesetzt. Man nennt so etwas eine
   Abstraktionsschicht - der Code darueber bleibt gleich, egal
   was darunter passiert.
   ============================================================ */

let backend = null;          // wird beim Start gesetzt
let katalog = null;
let installiert = {};
let letzterAbruf = null;
let installEreignis = null;

const SPIELE_CACHE = 'wolken-spiele-v1';
const SPEICHER_SCHLUESSEL = 'wolken_installiert';


/* ============================================================
   BACKEND 1: Das echte Programm
   ============================================================ */
const ProgrammBackend = {
  name: 'programm',
  datenordner: '',

  async status() {
    const antwort = await fetch('/api/status', { cache: 'no-store' });
    const daten = await antwort.json();
    this.datenordner = daten.datenordner;
    this.quelle = daten.quelle;
    this.onlineQuelle = daten.online_quelle;
    this.belegt = daten.belegt;
    return daten.installiert;
  },

  async katalog() {
    const antwort = await fetch('/api/katalog', { cache: 'no-store' });
    const daten = await antwort.json();
    if (daten.fehler) {
      if (daten.quelle) this.quelle = daten.quelle;
      throw new Error(daten.fehler);
    }
    return daten;
  },

  /**
   * Das Programm laedt im Hintergrund. Wir stossen es an und fragen
   * danach regelmaessig nach, wie weit es ist ("Polling").
   */
  async installieren(spiel, melden) {
    await fetch('/api/installieren', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ spiel: spiel })
    });

    while (true) {
      await warte(180);

      const alle = await fetch('/api/fortschritt', { cache: 'no-store' }).then(r => r.json());
      const stand = alle[spiel.id];
      if (!stand) continue;

      if (stand.fehler) throw new Error(stand.fehler);

      if (melden) melden(stand.fertig || 0, stand.gesamt || spiel.dateien.length, stand.datei || '');

      if (!stand.laeuft) break;
    }
  },

  async entfernen(spiel) {
    await fetch('/api/entfernen', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: spiel.id })
    });
  },

  startAdresse(spiel) {
    return 'spiele/' + spiel.id + '/' + spiel.start;
  },

  async ordnerOeffnen() {
    await fetch('/api/ordner-oeffnen');
  }
};


/* ============================================================
   BACKEND 2: Nur der Browser
   ============================================================ */
const BrowserBackend = {
  name: 'browser',

  async status() {
    try {
      return JSON.parse(localStorage.getItem(SPEICHER_SCHLUESSEL) || '{}');
    } catch (e) {
      return {};
    }
  },

  async katalog() {
    const antwort = await fetch('spiele.json?t=' + Date.now(), { cache: 'no-store' });
    if (!antwort.ok) throw new Error('Katalog nicht erreichbar (' + antwort.status + ')');
    return antwort.json();
  },

  async installieren(spiel, melden) {
    const cache = await caches.open(SPIELE_CACHE);
    const pfade = spiel.dateien.map(d => spiel.ordner + '/' + d);

    for (let i = 0; i < pfade.length; i++) {
      // cache: 'reload' erzwingt einen echten Abruf. Der Service Worker
      // laesst solche Anfragen bewusst durch - sonst bekaeme man beim
      // Update wieder die alte Datei.
      const antwort = await fetch(pfade[i], { cache: 'reload' });
      if (!antwort.ok) throw new Error('Datei fehlt: ' + pfade[i]);

      await cache.put(pfade[i], antwort.clone());
      if (melden) melden(i + 1, pfade.length, pfade[i]);
    }

    installiert[spiel.id] = {
      version: spiel.version,
      pruefsumme: spiel.pruefsumme,
      groesse: spiel.groesse,
      datum: new Date().toISOString()
    };
    localStorage.setItem(SPEICHER_SCHLUESSEL, JSON.stringify(installiert));
  },

  async entfernen(spiel) {
    const cache = await caches.open(SPIELE_CACHE);
    for (const datei of spiel.dateien) {
      await cache.delete(spiel.ordner + '/' + datei);
    }
    delete installiert[spiel.id];
    localStorage.setItem(SPEICHER_SCHLUESSEL, JSON.stringify(installiert));
  },

  startAdresse(spiel) {
    return spiel.ordner + '/' + spiel.start;
  }
};


function warte(ms) {
  return new Promise(r => setTimeout(r, ms));
}


/* ============================================================
   Versionsnummern vergleichen
   ------------------------------------------------------------
   Als Text verglichen waere "1.9.0" groesser als "1.10.0", weil
   9 > 1 ist. Deshalb zerlegen wir die Nummer und vergleichen die
   Teile als Zahlen.
   Rueckgabe: 1 = a neuer, -1 = b neuer, 0 = gleich
   ============================================================ */
function versionVergleich(a, b) {
  const teileA = String(a).split('.').map(Number);
  const teileB = String(b).split('.').map(Number);

  for (let i = 0; i < Math.max(teileA.length, teileB.length); i++) {
    const x = teileA[i] || 0;
    const y = teileB[i] || 0;
    if (x > y) return 1;
    if (x < y) return -1;
  }
  return 0;
}

function zustandVon(spiel) {
  const dabei = installiert[spiel.id];
  if (!dabei) return 'nicht-installiert';

  if (versionVergleich(spiel.version, dabei.version) > 0) return 'update';
  if (spiel.pruefsumme && dabei.pruefsumme && spiel.pruefsumme !== dabei.pruefsumme) return 'update';
  return 'installiert';
}


/* ============================================================
   OBERFLAECHE
   ============================================================ */
const bibliothek    = document.getElementById('bibliothek');
const ladeanzeige   = document.getElementById('ladeanzeige');
const dialog        = document.getElementById('dialog');
const dialogKoerper = document.getElementById('dialog-koerper');

function kbFormat(bytes) {
  if (!bytes) return '0 KB';
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(0) + ' KB';
  return (bytes / 1024 / 1024).toFixed(1) + ' MB';
}

function bibliothekZeichnen() {
  bibliothek.innerHTML = '';

  for (const spiel of katalog.spiele) {
    const zustand = zustandVon(spiel);
    const dabei = installiert[spiel.id];

    const karte = document.createElement('article');
    karte.className = 'karte zustand-' + zustand;
    karte.style.setProperty('--spielfarbe', spiel.farbe);

    let knoepfe, abzeichen = '';
    if (zustand === 'nicht-installiert') {
      knoepfe = '<button class="knopf haupt" data-tat="laden">Herunterladen'
              + '<span class="knopf-klein">' + kbFormat(spiel.groesse) + '</span></button>';
    } else if (zustand === 'update') {
      abzeichen = '<span class="abzeichen update">Update</span>';
      knoepfe = '<button class="knopf haupt update" data-tat="laden">Aktualisieren'
              + '<span class="knopf-klein">v' + dabei.version + ' &rarr; v' + spiel.version + '</span></button>'
              + '<button class="knopf zweit" data-tat="spielen">Spielen</button>';
    } else {
      abzeichen = '<span class="abzeichen ok">Installiert</span>';
      knoepfe = '<button class="knopf haupt" data-tat="spielen">Spielen</button>'
              + '<button class="knopf zweit" data-tat="entfernen">Entfernen</button>';
    }

    karte.innerHTML =
      '<div class="karte-bild"><div class="karte-glyphe">' + spiel.name.charAt(0) + '</div></div>' +
      '<div class="karte-koerper">' +
        '<div class="karte-kopf"><h2>' + spiel.name + '</h2>' + abzeichen + '</div>' +
        '<div class="karte-meta">' + spiel.genre + ' &middot; v' + spiel.version + '</div>' +
        '<p class="karte-kurz">' + spiel.kurz + '</p>' +
        '<div class="fortschritt versteckt"><div class="fortschritt-balken"></div></div>' +
        '<div class="fortschritt-text"></div>' +
        '<div class="karte-knoepfe">' + knoepfe +
          '<button class="knopf still" data-tat="info">Details</button></div>' +
      '</div>';

    karte.querySelectorAll('[data-tat]').forEach(knopf => {
      knopf.addEventListener('click', () => tatAusfuehren(knopf.dataset.tat, spiel, karte));
    });

    bibliothek.appendChild(karte);
  }

  statusAktualisieren();
}

async function tatAusfuehren(tat, spiel, karte) {
  if (tat === 'spielen') {
    window.location.href = backend.startAdresse(spiel);
    return;
  }

  if (tat === 'info') {
    detailsZeigen(spiel);
    return;
  }

  if (tat === 'entfernen') {
    if (!confirm('"' + spiel.name + '" wirklich entfernen?\n\nDu kannst es jederzeit neu herunterladen.')) return;
    await backend.entfernen(spiel);
    installiert = await backend.status();
    bibliothekZeichnen();
    return;
  }

  if (tat === 'laden') {
    const balken   = karte.querySelector('.fortschritt');
    const fuellung = karte.querySelector('.fortschritt-balken');
    const text     = karte.querySelector('.fortschritt-text');
    const knoepfe  = karte.querySelectorAll('.karte-knoepfe .knopf');

    balken.classList.remove('versteckt');
    knoepfe.forEach(k => k.disabled = true);
    text.classList.remove('fehler');

    try {
      await backend.installieren(spiel, (fertig, gesamt, datei) => {
        const prozent = gesamt ? Math.round(fertig / gesamt * 100) : 0;
        fuellung.style.width = prozent + '%';
        text.textContent = prozent + '%  ' + String(datei).split('/').pop();
      });

      text.textContent = 'Fertig';
      installiert = await backend.status();
      setTimeout(bibliothekZeichnen, 400);

    } catch (fehler) {
      text.textContent = 'Fehlgeschlagen: ' + fehler.message;
      text.classList.add('fehler');
      knoepfe.forEach(k => k.disabled = false);
    }
  }
}

/* ---------- Detail-Fenster ---------- */
function detailsZeigen(spiel) {
  const dabei = installiert[spiel.id];
  const zustand = zustandVon(spiel);

  let statusText;
  if (zustand === 'nicht-installiert') {
    statusText = 'Nicht installiert.';
  } else if (zustand === 'update') {
    statusText = 'Installiert in Version ' + dabei.version + '. Version ' + spiel.version + ' steht bereit.';
  } else {
    statusText = 'Installiert in Version ' + dabei.version + '.';
    if (dabei.pfad) statusText += '<br><span class="pfad">' + dabei.pfad + '</span>';
  }

  dialogKoerper.innerHTML =
    '<h2 class="dialog-titel">' + spiel.name + '</h2>' +
    '<div class="dialog-meta">' + spiel.genre + ' &middot; Version ' + spiel.version +
      ' &middot; ' + kbFormat(spiel.groesse) + ' &middot; ' + spiel.dateien.length + ' Dateien</div>' +
    '<p class="dialog-text">' + spiel.beschreibung + '</p>' +
    (spiel.neuerungen ? '<div class="dialog-abschnitt"><h3>Neu in dieser Version</h3><p>' + spiel.neuerungen + '</p></div>' : '') +
    '<div class="dialog-abschnitt"><h3>Status</h3><p>' + statusText + '</p></div>' +
    '<div class="dialog-abschnitt"><h3>Enthaltene Dateien</h3><ul class="dateiliste">' +
      spiel.dateien.map(d => '<li>' + d + '</li>').join('') + '</ul></div>';

  dialog.classList.remove('versteckt');
}

document.getElementById('dialog-schliessen').addEventListener('click', () => dialog.classList.add('versteckt'));
dialog.addEventListener('click', e => { if (e.target === dialog) dialog.classList.add('versteckt'); });

/* ---------- Statuszeile ---------- */
async function statusAktualisieren() {
  const anzahl  = katalog.spiele.filter(s => zustandVon(s) !== 'nicht-installiert').length;
  const updates = katalog.spiele.filter(s => zustandVon(s) === 'update').length;

  document.getElementById('status-installiert').textContent = anzahl;
  document.getElementById('status-updates').textContent = updates;

  let belegt = 0;
  if (backend.name === 'programm') {
    belegt = backend.belegt || 0;
  } else if (navigator.storage && navigator.storage.estimate) {
    try { belegt = (await navigator.storage.estimate()).usage || 0; } catch (e) {}
  }
  if (!belegt) {
    belegt = Object.values(installiert).reduce((s, e) => s + (e.groesse || 0), 0);
  }
  document.getElementById('status-speicher').textContent = kbFormat(belegt);

  document.getElementById('status-geprueft').textContent =
    letzterAbruf ? 'zuletzt geprueft ' + letzterAbruf.toLocaleTimeString('de-DE') : 'noch nicht geprueft';
}

/* ---------- Verbindung ---------- */
function verbindungAnzeigen() {
  const el = document.getElementById('verbindung');
  const text = document.getElementById('verbindung-text');

  if (backend && backend.name === 'programm' && !backend.onlineQuelle) {
    // Die Spiele liegen beim Programm selbst - Internet spielt keine Rolle
    el.classList.remove('offline');
    text.textContent = 'Lokale Quelle';
    return;
  }

  const online = navigator.onLine;
  el.classList.toggle('offline', !online);
  text.textContent = online ? 'Online' : 'Offline';
}
window.addEventListener('online', verbindungAnzeigen);
window.addEventListener('offline', verbindungAnzeigen);

/* ---------- Nach Updates suchen ---------- */
document.getElementById('pruefen-knopf').addEventListener('click', async () => {
  const knopf = document.getElementById('pruefen-knopf');
  knopf.disabled = true;
  knopf.textContent = 'Suche...';

  try {
    katalog = await backend.katalog();
    installiert = await backend.status();
    letzterAbruf = new Date();
    bibliothekZeichnen();

    const updates = katalog.spiele.filter(s => zustandVon(s) === 'update').length;
    knopf.textContent = updates > 0
      ? (updates + ' Update' + (updates > 1 ? 's' : '') + ' gefunden')
      : 'Alles aktuell';
  } catch (e) {
    knopf.textContent = 'Nicht erreichbar';
  }

  setTimeout(() => {
    knopf.textContent = 'Nach Updates suchen';
    knopf.disabled = false;
  }, 2500);
});

/* ---------- Spieleordner oeffnen (nur im Programm) ---------- */
document.getElementById('ordner-knopf').addEventListener('click', () => {
  if (backend.ordnerOeffnen) backend.ordnerOeffnen();
});

/* ---------- Launcher als App installieren (nur im Browser) ---------- */
window.addEventListener('beforeinstallprompt', (ereignis) => {
  ereignis.preventDefault();
  installEreignis = ereignis;
  if (backend && backend.name === 'browser') {
    document.getElementById('installieren-knopf').classList.remove('versteckt');
  }
});

document.getElementById('installieren-knopf').addEventListener('click', async () => {
  if (!installEreignis) return;
  installEreignis.prompt();
  const ergebnis = await installEreignis.userChoice;
  if (ergebnis.outcome === 'accepted') {
    document.getElementById('installieren-knopf').classList.add('versteckt');
  }
  installEreignis = null;
});

/* ============================================================
   START
   ============================================================ */
async function backendWaehlen() {
  // Antwortet /api/status? Dann steht ein echtes Programm dahinter.
  try {
    const antwort = await fetch('/api/status', { cache: 'no-store' });
    if (antwort.ok) {
      const daten = await antwort.json();
      if (daten.modus === 'programm') return ProgrammBackend;
    }
  } catch (e) {
    // kein Programm - dann eben der Browser
  }
  return BrowserBackend;
}

async function start() {
  backend = await backendWaehlen();
  document.body.dataset.modus = backend.name;

  if (backend.name === 'programm') {
    // Im Programm-Modus schreibt das Programm die Dateien auf die
    // Festplatte. Ein Service Worker waere hier nur im Weg - er wuerde
    // die API-Aufrufe abfangen.
    document.getElementById('ordner-knopf').classList.remove('versteckt');
    document.getElementById('modus-anzeige').textContent = 'Programm';

    if ('serviceWorker' in navigator) {
      for (const reg of await navigator.serviceWorker.getRegistrations()) {
        await reg.unregister();
      }
    }
  } else {
    document.getElementById('modus-anzeige').textContent = 'Browser';
    if ('serviceWorker' in navigator) {
      try { await navigator.serviceWorker.register('sw.js'); }
      catch (e) { console.warn('Service Worker nicht angemeldet:', e.message); }
    }
  }

  try {
    // Erst den Zustand holen, DANN die Verbindungsanzeige zeichnen.
    // Andersherum weiss sie noch nicht, ob die Quelle online ist,
    // und zeigt faelschlich "Lokale Quelle" an.
    installiert = await backend.status();
    verbindungAnzeigen();

    katalog = await backend.katalog();
    letzterAbruf = new Date();

    ladeanzeige.classList.add('versteckt');
    bibliothekZeichnen();

    if (backend.name === 'programm') {
      document.getElementById('fuss-pfad').textContent =
        'Spiele liegen unter: ' + backend.datenordner + '\\spiele';
    }
  } catch (fehler) {
    verbindungAnzeigen();
    ladeanzeige.innerHTML =
      'Katalog konnte nicht geladen werden.<br>' +
      '<span class="klein">' + fehler.message + '</span>' +
      (backend.quelle ? '<br><span class="klein pfad">Gesucht bei: ' + backend.quelle + '</span>' : '');
    ladeanzeige.classList.add('fehler');
  }
}

start();
