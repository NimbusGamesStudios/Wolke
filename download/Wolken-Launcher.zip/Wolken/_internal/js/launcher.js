/* ============================================================
   launcher.js  -  Der Wolken Launcher
   ------------------------------------------------------------
   Der Launcher kann in ZWEI Umgebungen laufen:

     PROGRAMM-MODUS   (Wolken.exe)
       Ein eigenes Programm hat den Server gestartet. Es schreibt
       richtige Dateien auf die Festplatte und zaehlt die Spielzeit.

     BROWSER-MODUS    (nur eine Webseite)
       Kein Programm dahinter. Dann bleibt der Speicher, den der
       Browser selbst anbietet: die Cache Storage API.

   Damit der Rest des Codes davon nichts wissen muss, gibt es fuer
   beide Faelle ein Objekt mit denselben Funktionen. Beim Start wird
   das passende eingesetzt - eine Abstraktionsschicht.
   ============================================================ */

let backend = null;
let katalog = null;
let installiert = {};
let ansicht = 'store';
let offenesSpiel = null;
let suchtext = '';

// Welche Downloads laufen gerade? id -> {fertig, gesamt, datei, fehler}
const laufend = {};

const SPIELE_CACHE = 'wolken-spiele-v1';
const SPEICHER_SCHLUESSEL = 'wolken_installiert';


/* ============================================================
   BACKEND 1: Das echte Programm
   ============================================================ */
const ProgrammBackend = {
  name: 'programm',

  async status() {
    const daten = await (await fetch('/api/status', { cache: 'no-store' })).json();
    this.datenordner = daten.datenordner;
    this.quelle = daten.quelle;
    this.onlineQuelle = daten.online_quelle;
    this.belegt = daten.belegt;
    this.version = daten.version;
    return daten.installiert;
  },

  async katalog() {
    const daten = await (await fetch('/api/katalog', { cache: 'no-store' })).json();
    if (daten.fehler) {
      if (daten.quelle) this.quelle = daten.quelle;
      throw new Error(daten.fehler);
    }
    return daten;
  },

  /**
   * Das Programm laedt im Hintergrund. Wir stossen es an und fragen
   * danach regelmaessig nach, wie weit es ist ("Polling").
   */
  async installieren(spiel, melden) {
    await post('/api/installieren', { spiel: spiel });

    while (true) {
      await warte(180);
      const alle = await (await fetch('/api/fortschritt', { cache: 'no-store' })).json();
      const stand = alle[spiel.id];
      if (!stand) continue;

      if (stand.fehler) throw new Error(stand.fehler);
      if (melden) melden(stand.fertig || 0, stand.gesamt || spiel.dateien.length, stand.datei || '');
      if (!stand.laeuft) break;
    }
  },

  async entfernen(spiel) { await post('/api/entfernen', { id: spiel.id }); },

  bildAdresse(spiel, was) {
    if (!spiel[was]) return null;
    return '/api/bild?spiel=' + encodeURIComponent(spiel.id) + '&name=' + was;
  },

  async starten(spiel) {
    await post('/api/gestartet', { id: spiel.id });
    window.location.href = 'spiele/' + spiel.id + '/' + spiel.start;
  },

  async ordnerOeffnen() { await fetch('/api/ordner-oeffnen'); },

  /** Meldet dem Programm, dass wir aus einem Spiel zurueck sind. */
  async zurueckgekehrt() {
    try { await post('/api/zurueck', {}); } catch (e) { /* egal */ }
  }
};


/* ============================================================
   BACKEND 2: Nur der Browser
   ============================================================ */
const BrowserBackend = {
  name: 'browser',

  async status() {
    try { return JSON.parse(localStorage.getItem(SPEICHER_SCHLUESSEL) || '{}'); }
    catch (e) { return {}; }
  },

  async katalog() {
    const antwort = await fetch('spiele.json?t=' + Date.now(), { cache: 'no-store' });
    if (!antwort.ok) throw new Error('Katalog nicht erreichbar (' + antwort.status + ')');
    return antwort.json();
  },

  async installieren(spiel, melden) {
    const cache = await caches.open(SPIELE_CACHE);
    const pfade = spiel.dateien.map(d => spiel.ordner + '/' + d);

    for (let i = 0; i < pfade.length; i++) {
      // cache: 'reload' erzwingt einen echten Abruf. Der Service Worker
      // laesst solche Anfragen bewusst durch - sonst bekaeme man beim
      // Update wieder die alte Datei.
      const antwort = await fetch(pfade[i], { cache: 'reload' });
      if (!antwort.ok) throw new Error('Datei fehlt: ' + pfade[i]);
      await cache.put(pfade[i], antwort.clone());
      if (melden) melden(i + 1, pfade.length, pfade[i]);
    }

    installiert[spiel.id] = {
      version: spiel.version,
      pruefsumme: spiel.pruefsumme,
      groesse: spiel.groesse,
      datum: new Date().toISOString()
    };
    localStorage.setItem(SPEICHER_SCHLUESSEL, JSON.stringify(installiert));
  },

  async entfernen(spiel) {
    const cache = await caches.open(SPIELE_CACHE);
    for (const datei of spiel.dateien) await cache.delete(spiel.ordner + '/' + datei);
    delete installiert[spiel.id];
    localStorage.setItem(SPEICHER_SCHLUESSEL, JSON.stringify(installiert));
  },

  bildAdresse(spiel, was) {
    return spiel[was] ? spiel.ordner + '/' + was + '.webp' : null;
  },

  async starten(spiel) { window.location.href = spiel.ordner + '/' + spiel.start; },
  async zurueckgekehrt() {}
};


/* ---------- kleine Helfer ---------- */
function warte(ms) { return new Promise(r => setTimeout(r, ms)); }

function post(pfad, daten) {
  return fetch(pfad, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(daten)
  });
}

function $(id) { return document.getElementById(id); }


/* ============================================================
   Versionsnummern vergleichen
   ------------------------------------------------------------
   Als Text verglichen waere "1.9.0" groesser als "1.10.0", weil
   9 > 1 ist. Deshalb zerlegen wir die Nummer und vergleichen die
   Teile als Zahlen.
   ============================================================ */
function versionVergleich(a, b) {
  const teileA = String(a).split('.').map(Number);
  const teileB = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(teileA.length, teileB.length); i++) {
    const x = teileA[i] || 0, y = teileB[i] || 0;
    if (x > y) return 1;
    if (x < y) return -1;
  }
  return 0;
}

function zustandVon(spiel) {
  if (laufend[spiel.id]) return 'laedt';
  const dabei = installiert[spiel.id];
  if (!dabei) return 'nicht-installiert';
  if (versionVergleich(spiel.version, dabei.version) > 0) return 'update';
  if (spiel.pruefsumme && dabei.pruefsumme && spiel.pruefsumme !== dabei.pruefsumme) return 'update';
  return 'installiert';
}


/* ============================================================
   Formatierungen
   ============================================================ */
function groesseText(bytes) {
  if (!bytes) return '0 KB';
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(0) + ' KB';
  return (bytes / 1024 / 1024).toFixed(1) + ' MB';
}

function spielzeitText(sekunden) {
  if (!sekunden) return 'noch nie gespielt';
  if (sekunden < 60) return sekunden + ' Sekunden';
  if (sekunden < 3600) return Math.round(sekunden / 60) + ' Minuten';
  return (sekunden / 3600).toFixed(1).replace('.', ',') + ' Stunden';
}

function datumText(iso) {
  if (!iso) return '-';
  const d = new Date(iso);
  if (isNaN(d)) return '-';
  return d.toLocaleDateString('de-DE') + ', ' + d.toLocaleTimeString('de-DE',
    { hour: '2-digit', minute: '2-digit' });
}


/* ============================================================
   ANSICHTEN WECHSELN
   ============================================================ */
const TITEL = {
  store: 'Store',
  bibliothek: 'Meine Spiele',
  downloads: 'Downloads',
  einstellungen: 'Optionen',
  detail: ''
};

function zeige(neu, spiel) {
  ansicht = neu;
  offenesSpiel = spiel || null;

  document.querySelectorAll('.ansicht').forEach(a => a.classList.remove('sichtbar'));
  const ziel = $('ansicht-' + (neu === 'detail' ? 'detail' : neu));
  if (ziel) ziel.classList.add('sichtbar');

  document.querySelectorAll('.rail-knopf').forEach(k =>
    k.classList.toggle('aktiv', k.dataset.ansicht === neu));

  $('leiste-titel').textContent = neu === 'detail' ? (spiel ? spiel.name : '') : TITEL[neu];
  $('zurueck-knopf').classList.toggle('versteckt', neu !== 'detail');
  document.querySelector('.suche-feld').classList.toggle('versteckt',
    neu !== 'store' && neu !== 'bibliothek');

  $('inhalt').scrollTop = 0;

  if (neu === 'detail') detailZeichnen(spiel);
  else if (neu === 'downloads') downloadsZeichnen();
  else if (neu === 'einstellungen') einstellungenZeichnen();
  else regaleZeichnen();
}


/* ============================================================
   REGALE (Store und Bibliothek)
   ============================================================ */
function passtZurSuche(spiel) {
  if (!suchtext) return true;
  const t = suchtext.toLowerCase();
  return (spiel.name + ' ' + spiel.kurz + ' ' + spiel.genre).toLowerCase().includes(t);
}

function kapselBauen(spiel) {
  const zustand = zustandVon(spiel);
  const dabei = installiert[spiel.id];

  const el = document.createElement('article');
  el.className = 'kapsel';
  el.style.setProperty('--spielfarbe', spiel.farbe);

  const bild = backend.bildAdresse(spiel, 'kapsel');
  const bildTeil = bild
    ? '<img src="' + bild + '" alt="' + spiel.name + '" loading="lazy">'
    : '<div class="kapsel-ersatz">' + spiel.name.charAt(0) + '</div>';

  let abzeichen = '';
  if (zustand === 'installiert')  abzeichen = '<span class="kapsel-abzeichen ok">Bereit</span>';
  if (zustand === 'update')       abzeichen = '<span class="kapsel-abzeichen update">Update</span>';
  if (zustand === 'laedt')        abzeichen = '<span class="kapsel-abzeichen laedt">Laedt</span>';

  let fuss = spiel.genre;
  if (dabei && dabei.spielzeit) fuss = spielzeitText(dabei.spielzeit);

  let balken = '';
  if (zustand === 'laedt') {
    const s = laufend[spiel.id];
    const p = s.gesamt ? Math.round(s.fertig / s.gesamt * 100) : 0;
    balken = '<div class="kapsel-balken"><i style="width:' + p + '%"></i></div>';
  }

  el.innerHTML = bildTeil + abzeichen +
                 '<div class="kapsel-fuss">' + fuss + '</div>' + balken;

  el.addEventListener('click', () => zeige('detail', spiel));
  return el;
}

function regaleZeichnen() {
  if (!katalog) return;

  // ---- Store: alles ----
  const store = $('regal-store');
  store.innerHTML = '';
  katalog.spiele.filter(passtZurSuche).forEach(s => store.appendChild(kapselBauen(s)));

  heroZeichnen();

  // ---- Bibliothek: nur Installiertes ----
  const bib = $('regal-bibliothek');
  bib.innerHTML = '';
  const meine = katalog.spiele
    .filter(s => installiert[s.id])
    .filter(passtZurSuche)
    .sort((a, b) => {
      // Zuletzt gespieltes zuerst - so macht es Steam auch
      const za = installiert[a.id].zuletzt || '';
      const zb = installiert[b.id].zuletzt || '';
      return zb.localeCompare(za);
    });

  meine.forEach(s => bib.appendChild(kapselBauen(s)));
  $('bibliothek-leer').classList.toggle('versteckt', meine.length > 0);

  railPunktSetzen();
}

/** Der grosse Banner oben im Store zeigt das erste Spiel mit Bannerbild. */
function heroZeichnen() {
  const hero = $('hero');
  const spiel = katalog.spiele.find(s => s.banner);

  if (!spiel || suchtext) { hero.classList.add('versteckt'); return; }
  hero.classList.remove('versteckt');

  const zustand = zustandVon(spiel);
  const knopfText = zustand === 'nicht-installiert' ? 'Herunterladen'
                  : zustand === 'update' ? 'Aktualisieren'
                  : zustand === 'laedt' ? 'Laedt...' : 'Spielen';

  hero.innerHTML =
    '<img src="' + backend.bildAdresse(spiel, 'banner') + '" alt="">' +
    '<div class="hero-schleier"></div>' +
    '<div class="hero-inhalt">' +
      '<div class="hero-marke">Neu im Launcher</div>' +
      '<h2>' + spiel.name + '</h2>' +
      '<p>' + spiel.kurz + '</p>' +
      '<button class="knopf ' + (zustand === 'installiert' ? 'spielen' : 'haupt') + '">' +
        knopfText + '</button>' +
    '</div>';

  hero.querySelector('button').addEventListener('click', (e) => {
    e.stopPropagation();
    hauptTat(spiel);
  });
  hero.querySelector('img').addEventListener('click', () => zeige('detail', spiel));
}

function railPunktSetzen() {
  const offen = katalog
    ? katalog.spiele.filter(s => zustandVon(s) === 'update' || zustandVon(s) === 'laedt').length
    : 0;
  $('rail-punkt').classList.toggle('versteckt', offen === 0);
}


/* ============================================================
   DETAILSEITE
   ============================================================ */
function detailZeichnen(spiel) {
  if (!spiel) return;

  const zustand = zustandVon(spiel);
  const dabei = installiert[spiel.id];
  const banner = backend.bildAdresse(spiel, 'banner');

  let knoepfe;
  if (zustand === 'laedt') {
    const s = laufend[spiel.id];
    const p = s.gesamt ? Math.round(s.fertig / s.gesamt * 100) : 0;
    knoepfe = '<button class="knopf haupt" disabled>Laedt ' + p + '%</button>';
  } else if (zustand === 'nicht-installiert') {
    knoepfe = '<button class="knopf haupt" data-tat="laden">Herunterladen' +
              '<span class="knopf-klein-text">' + groesseText(spiel.groesse) + '</span></button>';
  } else if (zustand === 'update') {
    // Gleiche Versionsnummer, aber andere Pruefsumme? Dann haben sich
    // Dateien geaendert, ohne dass die Version erhoeht wurde.
    // "v1.2.0 -> v1.2.0" waere sinnlos - also anders beschriften.
    const echtesUpdate = versionVergleich(spiel.version, dabei.version) > 0;
    knoepfe = '<button class="knopf update" data-tat="laden">' +
              (echtesUpdate ? 'Aktualisieren' : 'Dateien erneuern') +
              '<span class="knopf-klein-text">' +
              (echtesUpdate ? 'v' + dabei.version + ' &rarr; v' + spiel.version
                            : 'Inhalt hat sich geaendert') +
              '</span></button>' +
              '<button class="knopf zweit" data-tat="spielen">Spielen</button>';
  } else {
    knoepfe = '<button class="knopf spielen" data-tat="spielen">Spielen</button>' +
              '<button class="knopf zweit" data-tat="entfernen">Entfernen</button>';
  }

  const seite = [
    ['Version', 'v' + spiel.version],
    ['Genre', spiel.genre],
    ['Groesse', groesseText(spiel.groesse)],
    ['Dateien', spiel.dateien.length],
  ];
  if (dabei) {
    seite.push(['Installiert', 'v' + dabei.version]);
    seite.push(['Gespielt', spielzeitText(dabei.spielzeit)]);
    if (dabei.starts) seite.push(['Gestartet', dabei.starts + ' mal']);
    if (dabei.zuletzt) seite.push(['Zuletzt', datumText(dabei.zuletzt)]);
  }

  $('ansicht-detail').innerHTML =
    '<div class="detail-banner">' +
      (banner ? '<img src="' + banner + '" alt="">' : '') +
      '<div class="hero-schleier"></div>' +
      '<div class="detail-kopf">' +
        '<div><h2>' + spiel.name + '</h2>' +
          '<div class="detail-meta"><span>' + spiel.genre + '</span>' +
          '<span>v' + spiel.version + '</span>' +
          '<span>' + groesseText(spiel.groesse) + '</span></div></div>' +
        '<div class="detail-knoepfe">' + knoepfe + '</div>' +
      '</div>' +
    '</div>' +

    '<div class="detail-spalten">' +
      '<div class="detail-text">' +
        '<h3>Worum es geht</h3><p>' + spiel.beschreibung + '</p>' +
        (spiel.neuerungen ? '<h3>Neu in v' + spiel.version + '</h3><p>' + spiel.neuerungen + '</p>' : '') +
        '<h3>Enthaltene Dateien</h3>' +
        '<ul class="dateiliste">' + spiel.dateien.map(d => '<li>' + d + '</li>').join('') + '</ul>' +
      '</div>' +
      '<aside class="detail-seite">' +
        seite.map(z => '<div class="detail-zeile"><b>' + z[0] + '</b><span>' + z[1] + '</span></div>').join('') +
      '</aside>' +
    '</div>';

  $('ansicht-detail').querySelectorAll('[data-tat]').forEach(k =>
    k.addEventListener('click', () => tat(k.dataset.tat, spiel)));
}


/* ============================================================
   AKTIONEN
   ============================================================ */
function hauptTat(spiel) {
  const z = zustandVon(spiel);
  if (z === 'laedt') return;
  tat(z === 'installiert' ? 'spielen' : 'laden', spiel);
}

async function tat(welche, spiel) {
  if (welche === 'spielen') { await backend.starten(spiel); return; }

  if (welche === 'entfernen') {
    if (!confirm('"' + spiel.name + '" wirklich entfernen?\n\nDu kannst es jederzeit neu herunterladen.')) return;
    await backend.entfernen(spiel);
    installiert = await backend.status();
    zeige(ansicht === 'detail' ? 'detail' : ansicht, spiel);
    return;
  }

  if (welche === 'laden') {
    laufend[spiel.id] = { fertig: 0, gesamt: spiel.dateien.length, datei: '' };
    aktualisiereAnsicht();

    try {
      await backend.installieren(spiel, (fertig, gesamt, datei) => {
        laufend[spiel.id] = { fertig, gesamt, datei };
        aktualisiereAnsicht();
      });
      delete laufend[spiel.id];
      installiert = await backend.status();
    } catch (fehler) {
      laufend[spiel.id] = { fertig: 0, gesamt: 0, datei: '', fehler: fehler.message };
      setTimeout(() => { delete laufend[spiel.id]; aktualisiereAnsicht(); }, 6000);
    }
    aktualisiereAnsicht();
  }
}

/** Zeichnet nur die gerade sichtbare Ansicht neu. */
function aktualisiereAnsicht() {
  if (ansicht === 'detail') detailZeichnen(offenesSpiel);
  else if (ansicht === 'downloads') downloadsZeichnen();
  else regaleZeichnen();
  railPunktSetzen();
}


/* ============================================================
   DOWNLOADS
   ============================================================ */
function downloadsZeichnen() {
  const liste = $('download-liste');
  const ids = Object.keys(laufend);
  liste.innerHTML = '';

  $('downloads-leer').classList.toggle('versteckt', ids.length > 0);

  for (const id of ids) {
    const spiel = katalog.spiele.find(s => s.id === id);
    if (!spiel) continue;

    const s = laufend[id];
    const p = s.gesamt ? Math.round(s.fertig / s.gesamt * 100) : 0;
    const bild = backend.bildAdresse(spiel, 'kapsel');

    const el = document.createElement('div');
    el.className = 'download-eintrag';
    el.innerHTML =
      (bild ? '<img class="download-bild" src="' + bild + '" alt="">' : '<div class="download-bild"></div>') +
      '<div class="download-mitte">' +
        '<h4>' + spiel.name + '</h4>' +
        (s.fehler
          ? '<div class="download-fehler">Fehlgeschlagen: ' + s.fehler + '</div>'
          : '<div class="download-datei">' + (s.datei || 'wird vorbereitet...') + '</div>' +
            '<div class="balken"><i style="width:' + p + '%"></i></div>') +
      '</div>' +
      (s.fehler ? '' : '<div class="download-prozent">' + p + '%</div>');

    liste.appendChild(el);
  }
}


/* ============================================================
   EINSTELLUNGEN
   ============================================================ */
function einstellungenZeichnen() {
  $('opt-quelle').textContent = backend.quelle || 'Dateien der Webseite';
  $('opt-ordner').textContent = backend.datenordner || 'Browser-Speicher';
  $('opt-platz').textContent = groesseText(backend.belegt ||
    Object.values(installiert).reduce((s, e) => s + (e.groesse || 0), 0));
  $('opt-version').textContent = backend.version ? 'v' + backend.version : '(Browser-Modus)';
  $('ordner-knopf').classList.toggle('versteckt', !backend.ordnerOeffnen);
}


/* ============================================================
   Verbindungsanzeige
   ============================================================ */
function verbindungAnzeigen() {
  const el = $('verbindung');
  const text = $('verbindung-text');

  if (backend && backend.name === 'programm' && backend.onlineQuelle === false) {
    el.classList.remove('offline');
    text.textContent = 'Lokale Quelle';
    return;
  }
  el.classList.toggle('offline', !navigator.onLine);
  text.textContent = navigator.onLine ? 'Online' : 'Offline';
}

window.addEventListener('online', verbindungAnzeigen);
window.addEventListener('offline', verbindungAnzeigen);


/* ============================================================
   Bedienelemente
   ============================================================ */
document.querySelectorAll('.rail-knopf').forEach(k =>
  k.addEventListener('click', () => zeige(k.dataset.ansicht)));

document.querySelectorAll('[data-gehe]').forEach(k =>
  k.addEventListener('click', () => zeige(k.dataset.gehe)));

$('zurueck-knopf').addEventListener('click', () => zeige('store'));

$('suche').addEventListener('input', (e) => {
  suchtext = e.target.value.trim();
  if (ansicht === 'store' || ansicht === 'bibliothek') regaleZeichnen();
});

$('ordner-knopf').addEventListener('click', () => {
  if (backend.ordnerOeffnen) backend.ordnerOeffnen();
});

$('pruefen-knopf').addEventListener('click', async () => {
  const knopf = $('pruefen-knopf');
  knopf.disabled = true;
  knopf.textContent = 'Suche...';

  try {
    katalog = await backend.katalog();
    installiert = await backend.status();
    aktualisiereAnsicht();
    const n = katalog.spiele.filter(s => zustandVon(s) === 'update').length;
    knopf.textContent = n > 0 ? (n + ' Update' + (n > 1 ? 's' : '') + ' gefunden') : 'Alles aktuell';
  } catch (e) {
    knopf.textContent = 'Nicht erreichbar';
  }

  setTimeout(() => { knopf.textContent = 'Nach Updates suchen'; knopf.disabled = false; }, 2500);
});


/* ============================================================
   START
   ============================================================ */
async function backendWaehlen() {
  // Antwortet /api/status? Dann steht ein echtes Programm dahinter.
  try {
    const antwort = await fetch('/api/status', { cache: 'no-store' });
    if (antwort.ok && (await antwort.json()).modus === 'programm') return ProgrammBackend;
  } catch (e) { /* kein Programm - dann eben der Browser */ }
  return BrowserBackend;
}

async function start() {
  backend = await backendWaehlen();
  document.body.dataset.modus = backend.name;

  if (backend.name === 'programm') {
    // Ein Service Worker wuerde hier die API-Aufrufe abfangen.
    if ('serviceWorker' in navigator) {
      for (const reg of await navigator.serviceWorker.getRegistrations()) await reg.unregister();
    }
    // Zurueck aus einem Spiel? Dann Spielzeit abrechnen.
    await backend.zurueckgekehrt();
  } else if ('serviceWorker' in navigator) {
    try { await navigator.serviceWorker.register('sw.js'); }
    catch (e) { console.warn('Service Worker nicht angemeldet:', e.message); }
  }

  try {
    installiert = await backend.status();
    verbindungAnzeigen();
    katalog = await backend.katalog();

    $('ladeanzeige').classList.add('versteckt');
    zeige(Object.keys(installiert).length > 0 ? 'bibliothek' : 'store');

  } catch (fehler) {
    verbindungAnzeigen();
    $('ladeanzeige').innerHTML =
      'Katalog konnte nicht geladen werden.<br>' +
      '<span class="klein">' + fehler.message + '</span>' +
      (backend.quelle ? '<br><span class="klein pfad">Gesucht bei: ' + backend.quelle + '</span>' : '');
    $('ladeanzeige').classList.add('fehler');
  }
}

start();
